import { Component } from '@angular/core';

@Component({
  selector: 'app-all-attendance',
  templateUrl: './all-attendance.component.html',
  styleUrls: ['./all-attendance.component.css']
})
export class AllAttendanceComponent {

}
